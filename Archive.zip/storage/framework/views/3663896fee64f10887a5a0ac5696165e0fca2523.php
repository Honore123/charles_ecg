<?php $__env->startSection('content'); ?>
    <div>
        <div class="row">
            <div class="col-md-12 mb-4">
                <h3 class="font-weight-bold">Welcome <?php echo e(auth()->user()->name); ?></h3>
                <h6 class="font-weight-normal mb-0">All systems are running smoothly! You have <span class="text-primary">3 pending reports!</span></h6>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 mb-4 stretch-card transparent">
              <div class="card card-tale">
                <div class="card-body">
                  <p class="mb-4">Pending Reports</p>
                  <p class="fs-30 mb-2">4,000</p>
                  
                </div>
              </div>
            </div>
            <div class="col-md-6 mb-4 stretch-card transparent">
              <div class="card card-dark-blue">
                <div class="card-body">
                  <p class="mb-4">Total Patients</p>
                  <p class="fs-30 mb-2"><?php echo e($patient); ?></p>
                  
                </div>
              </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/honore/Documents/Laravel_Projects/ECG_Web/resources/views/dashboard/dashboard.blade.php ENDPATH**/ ?>