<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-6 mb-4">
            <h3 class="font-weight-bold">Edit Patient</h3>
            <h6 class="font-weight-normal mb-0"><?php echo e($patient->firstname); ?> <?php echo e($patient->lastname); ?></h6>
        </div>
        <div class="col-md-6 text-right">
            <a class="btn btn-primary" href="<?php echo e(route('patient.index')); ?>">
                <i class="ti-angle-left"></i> Back
             </a>
        </div>
        <div class="col-md-12 grid-margin stretch-card">
            <div class="card">
                <form action="<?php echo e(route('patient.update', $patient->id)); ?>" method="POST">
                  <?php echo method_field('PUT'); ?>
                  <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="card-body">
                                <p class="card-description">
                                  Personal Information
                                </p>
                                  <div class="form-group">
                                    <label for="firstname">Firstname</label>
                                    <input type="text" class="form-control" id="firstname" placeholder="Ex: John" name="firstname" value="<?php echo e($patient->firstname); ?>">
                                  </div>
                                  <div class="form-group">
                                    <label for="lastname">Lastname</label>
                                    <input type="text" class="form-control" id="lastname" placeholder="Ex: Doe" name="lastname" value="<?php echo e($patient->lastname); ?>">
                                  </div>
                                  <div class="form-group">
                                    <label for="email">Email</label>
                                    <input type="email" class="form-control" id="email" placeholder="Password" name="email" value="<?php echo e($patient->email); ?>">
                                  </div>
                                  <div class="form-group">
                                    <label for="phoneNumber">Phone number</label>
                                    <input type="number" class="form-control" id="phone_number" placeholder="Ex: 250788000000" name="phone_number" value="<?php echo e($patient->phone_number); ?>">
                                  </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="card-body">
                                <p class="card-description">
                                  Other Information
                                </p>
                                  <div class="form-group">
                                    <label for="exampleInputUsername1">District</label>
                                    <input type="text" class="form-control" id="district" placeholder="Ex: Nyarugenge" name="district" value="<?php echo e($patient->district); ?>">
                                  </div>
                                  <div class="form-group">
                                    <label for="exampleInputEmail1">Province/City</label>
                                    <input type="text" class="form-control" id="province" placeholder="Ex: Kigali" name="province" value="<?php echo e($patient->province); ?>">
                                  </div>
                                  <div class="form-group">
                                    <label for="exampleInputConfirmPassword1">Other Information</label>
                                    <textarea name="comments" id="comments" class="form-control" cols="30" rows="9" placeholder="Any Comment"><?php echo e($patient->other_information); ?></textarea>
                                  </div>
                                  <div class="text-right">
                                    <button type="submit" class="btn btn-primary mt-3 mb-2 w-50">Update</button>
                                  </div>
                            </div>
                        </div>
                        
                    </div>
                </form>
            </div>
          </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/honore/Documents/Laravel_Projects/ECG_Web/resources/views/patient/edit.blade.php ENDPATH**/ ?>