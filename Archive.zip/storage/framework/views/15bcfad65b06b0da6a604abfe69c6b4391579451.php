<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-6 mb-4">
            <h3 class="font-weight-bold">Change your password</h3>
            <h6 class="font-weight-normal mb-0">Fill the form below.</h6>
        </div>
        <div class="col-md-6 text-right">
            
        </div>
        <div class="col-md-12">
            <?php echo $__env->make('layouts.partials.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-md-6 grid-margin stretch-card">
            <div class="card">
                <form action="<?php echo e(route('setting.update', auth()->user()->id)); ?>" method="POST">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="card-body">
                        <p class="card-description">
                            Reset password
                        </p>
                        <div class="form-group">
                        <label for="firstname">Current password</label>
                        <input type="password" class="form-control" id="current_password" name="currentPassword">
                        </div>
                        <div class="form-group">
                        <label for="lastname">New password</label>
                        <input type="password" class="form-control" id="password" name="password">
                        </div>
                        <div class="form-group">
                        <label for="email">Confirm password</label>
                        <input type="password" class="form-control" id="confirmation" name="password_confirmation">
                        </div>
                        <button type="submit" class="btn btn-primary mt-3 mb-2 w-50">Change</button>
                    </div>
                </form>
            </div>
          </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/honore/Documents/Laravel_Projects/ECG_Web/resources/views/settings/change_password.blade.php ENDPATH**/ ?>