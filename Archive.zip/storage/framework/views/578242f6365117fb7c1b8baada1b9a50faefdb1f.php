<?php echo e($slot); ?>

<?php /**PATH /Users/honore/Documents/Laravel_Projects/ECG_Web/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>