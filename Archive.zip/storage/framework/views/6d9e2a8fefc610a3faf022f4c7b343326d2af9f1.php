<!-- partial:partials/_sidebar.html -->
<nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">
      <li class="nav-item <?php echo e(setActive('/')); ?>">
        <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
          <i class="icon-grid menu-icon"></i>
          <span class="menu-title">Dashboard</span>
        </a>
      </li>
      <li class="nav-item <?php echo e(setActive('patients')); ?> <?php echo e(setActive('patients/*')); ?>">
        <a class="nav-link" href="<?php echo e(route('patient.index')); ?>">
          <i class="icon-head menu-icon"></i>
          <span class="menu-title">Patients</span>
        </a>
      </li>
      <li class="nav-item <?php echo e(setActive('settings')); ?>">
        <a class="nav-link" href="<?php echo e(route('setting.index')); ?>">
          <i class="icon-head menu-icon ti-key"></i>
          <span class="menu-title">Change Password</span>
        </a>
      </li>
    </ul>
</nav><?php /**PATH /Users/honore/Documents/Laravel_Projects/ECG_Web/resources/views/layouts/partials/sidebar.blade.php ENDPATH**/ ?>