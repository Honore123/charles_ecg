<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-6 mb-4">
            <h3 class="font-weight-bold"><?php echo e($patient->firstname); ?> <?php echo e($patient->lastname); ?></h3>
            <h6 class="font-weight-normal mb-0">Patient's Statistical data</h6>
        </div>
        <div class="col-md-6 text-right">
          <a class="btn btn-success mr-5" href="<?php echo e(route('patient.notify',$patient->id)); ?>">
            <i class="ti-bell"></i> Notify Patient
         </a>
            <a class="btn btn-primary" href="<?php echo e(route('patient.index')); ?>">
                <i class="ti-angle-left"></i> Back
             </a>
        </div>
        <?php if($patient->status == 0): ?>
          <div class="col-md-12">
            <div class="card">
              <div class="card-body">
                <p>Patient has revocked data visibility. Mean while you can contact him/her by pressing <span class="badge bg-success text-white">Notification</span> Button</p>

              </div>
            </div>
          </div>
        <?php else: ?>
        <div class="col-md-12 grid-margin stretch-card">
            <div class="card">
              <div class="card-body">
                <div class="row">
                  <div class="col"><h4 class="card-title">ECG Graph</h4></div>
                  <div class="col text-right">Heart Rate: <span class="badge bg-success text-white"><?php echo e(isset($heart->heart_rate) ? $heart->heart_rate : 'No data'); ?></span>  |  Heart Rate Variability: 
                    <span class="badge bg-primary text-white"><?php echo e(isset($heart->heart_rate_variability) ? $heart->heart_rate_variability : 'No data'); ?></span></div>
                </div>
                <canvas id="ecg_data_chart"></canvas>
              </div>
            </div>
        </div>
        <div class="col-lg-12 grid-margin stretch-card">
          <div class="card">
            <div class="card-body">
              
              <div class="table-responsive">
                <table class="table table-bordered table-hover" id="patient_data">
                  <thead>
                    <tr>
                      <th>
                        #
                      </th>
                      <th>
                        ECG Data
                      </th>
                      
                      <th>
                        Recorded At
                      </th>
                    </tr>
                  </thead>
                 <tbody>
                      <?php $__empty_1 = true; $__currentLoopData = $ecgDatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ecg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                          <tr>
                              <td><?php echo e($loop->iteration++); ?></td>
                              <td><?php echo e($ecg->data); ?></td>
                              
                              <td><?php echo e($ecg->created_at); ?></td>
                          </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                      <?php endif; ?>
                 </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
        <?php endif; ?>
  
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
      $('#patient_data').DataTable();
      $(document).ready(function(){
            setInterval(function(){
                $('#average_emission').val()
                var url = "<?php echo e(url('chart/data/'.$patient->id)); ?>";
        var dateTime = new Array();
        var ecgData = new Array();
            $.get(url, function(response){
                response.forEach(function(data){
                    dateTime.push(data.recorded_time);
                    ecgData.push(data.data);
                });
                var ecgChart = document.getElementById("ecg_data_chart").getContext('2d');

                var ecgDiagram = new Chart(ecgChart, {
                    type: 'line',
                    data: {
                        labels:dateTime,
                        datasets: [{
                            label: 'ECG Level',
                            data: ecgData,
                            borderWidth: 3,
                            borderColor: 'rgb(0, 127, 212)',
                            fill:false,
                            tension: 0.3,
                            pointRadius: 0
                        }]
                    },
                    options: {
                        animation:{
                            duration: 0
                        },
                        scales: {
                            yAxes: [{
                                ticks: {
                                    beginAtZero:true,
                                    userCallback: function(value, index, values) {
                                        value = value.toString();
                                        value = value.split(/(?=(?:...)*$)/);
                                        value = value.join(',');
                                        return value;
                                    }
                                }
                            }],

                            xAxes: [{
                                gridLines: {
                                    color: '#f2f3f8'
                                },
                                ticks: {
                                    display: false //this will remove only the label
                                }
                            }]
                        },
                    }
                });
            });
            },1000)

        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/honore/Documents/Laravel_Projects/ECG_Web/resources/views/patient/patient_data.blade.php ENDPATH**/ ?>