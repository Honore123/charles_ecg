<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'ECG')); ?></title>

        <link rel="stylesheet" href="<?php echo e(asset('assets/feather/feather.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/ti-icons/css/themify-icons.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/vendor.bundle.base.css')); ?>">
        <!-- endinject -->
        <!-- Plugin css for this page -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/datatables.net-bs4/dataTables.bootstrap4.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/ti-icons/css/themify-icons.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('custom/js/select.dataTables.min.css')); ?>">
        <!-- End plugin css for this page -->
        <!-- inject:css -->
        <link rel="stylesheet" href="<?php echo e(asset('custom/css/vertical-layout-light/style.css')); ?>">
        <!-- endinject -->
        <link rel="shortcut icon" href="<?php echo e(asset('images/favicon.png')); ?>" />
        <?php echo $__env->yieldPushContent('styles'); ?>
    </head>
    <body>
        <div class="container-scroller">
           <?php echo $__env->make('layouts.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
           
            <div class="container-fluid page-body-wrapper">
             <?php echo $__env->make('layouts.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              
              
              <div class="main-panel">
                <div class="content-wrapper">
                    <?php echo $__env->yieldContent('content'); ?>
                 </div>
               
                <?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              </div>
              
            </div>   
            
          </div>
        <script src="<?php echo e(asset('assets/js/vendor.bundle.base.js')); ?>"></script>
        <!-- endinject -->
        <!-- Plugin js for this page -->
        <script src="<?php echo e(asset('assets/chart.js/Chart.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/datatables.net/jquery.dataTables.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/datatables.net-bs4/dataTables.bootstrap4.js')); ?>"></script>
        <script src="<?php echo e(asset('custom/js/dataTables.select.min.js')); ?>"></script>
      
        <!-- End plugin js for this page -->
        <!-- inject:js -->
        <script src="<?php echo e(asset('custom/js/off-canvas.js')); ?>"></script>
        <script src="<?php echo e(asset('custom/js/hoverable-collapse.js')); ?>"></script>
        <script src="<?php echo e(asset('custom/js/template.js')); ?>"></script>
        <script src="<?php echo e(asset('custom/js/settings.js')); ?>"></script>
        <script src="<?php echo e(asset('custom/js/todolist.js')); ?>"></script>
        <!-- endinject -->
        <!-- Custom js for this page-->
        <script src="<?php echo e(asset('custom/js/dashboard.js')); ?>"></script>
        <script src="js/Chart.roundedBarCharts.js"></script>
        <!-- End custom js for this page-->
        <?php echo $__env->yieldPushContent('scripts'); ?>
    </body>
</html>
<?php /**PATH /Users/honore/Documents/Laravel_Projects/ECG_Web/resources/views/layouts/app.blade.php ENDPATH**/ ?>