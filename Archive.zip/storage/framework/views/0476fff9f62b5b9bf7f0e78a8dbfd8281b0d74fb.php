<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>
        <link rel="stylesheet" href="<?php echo e(asset('assets/feather/feather.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/ti-icons/css/themify-icons.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/vendor.bundle.base.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('custom/css/vertical-layout-light/style.css')); ?>">
        <link rel="shortcut icon" href="<?php echo e(asset('images/favicon.png')); ?>" />

    </head>
    <body>
        <div class="container-scroller">
            <div class="container-fluid page-body-wrapper full-page-wrapper">
            <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
        
        <script src="<?php echo e(asset('assets/js/vendor.bundle.base.js')); ?>"></script>
        <script src="<?php echo e(asset('custom/js/off-canvas.js')); ?>"></script>
        <script src="<?php echo e(asset('custom/js/hoverable-collapse.js')); ?>"></script>
        <script src="<?php echo e(asset('custom/js/template.js')); ?>"></script>
        <script src="<?php echo e(asset('custom/js/settings.js')); ?>"></script>
        <script src="<?php echo e(asset('custom/js/todolist.js')); ?>"></script>
    </body>
</html>
<?php /**PATH /Users/honore/Documents/Laravel_Projects/ECG_Web/resources/views/layouts/guest.blade.php ENDPATH**/ ?>