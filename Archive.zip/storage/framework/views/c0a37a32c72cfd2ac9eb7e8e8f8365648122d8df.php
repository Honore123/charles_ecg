 <!-- partial:partials/_navbar.html -->
 <nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
    <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
      <a class="navbar-brand brand-logo mr-5" href="index.html"><img src="<?php echo e(asset('images/logo_ecg.svg')); ?>" class="mr-2" alt="logo"/></a>
      <a class="navbar-brand brand-logo-mini" href="index.html"><img src="<?php echo e(asset('images/logo_mini_ecg.svg')); ?>" alt="logo"/></a>
    </div>
    <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end">
      <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
        <span class="icon-menu"></span>
      </button>
      
      <ul class="navbar-nav navbar-nav-right">
        
        <li class="nav-item nav-profile dropdown">
          <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown" id="profileDropdown">
            <img src="<?php echo e(asset('images/faces/face29.jpg')); ?>" alt="profile"/>
          </a>
          <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="profileDropdown">
            <a class="dropdown-item" href="<?php echo e(route('setting.index')); ?>">
              <i class="ti-settings text-primary"></i>
              Settings
            </a>
            <form action="<?php echo e(route('logout')); ?>" method="POST">
              <?php echo csrf_field(); ?>
              <a class="dropdown-item" onclick="event.preventDefault(); this.closest('form').submit();">
                <i class="ti-power-off text-primary"></i>
                Logout
              </a>
            </form>
          </div>
        </li>  
      </ul>
    </div>
  </nav><?php /**PATH /Users/honore/Documents/Laravel_Projects/ECG_Web/resources/views/layouts/partials/navbar.blade.php ENDPATH**/ ?>