<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <h1>Dashboard</h1>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/honore/Documents/Laravel_Projects/ECG_Web/resources/views/dashboard.blade.php ENDPATH**/ ?>