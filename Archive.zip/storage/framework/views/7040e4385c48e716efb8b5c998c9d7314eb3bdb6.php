<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-6 mb-4">
            <h3 class="font-weight-bold">Manage Patients</h3>
            <h6 class="font-weight-normal mb-0">Total Patients: <span class="text-primary"><?php echo e($patients->count()); ?></span></h6>
        </div>
        <div class="col-md-6 text-right">
            <a class="btn btn-primary" href="<?php echo e(route('patient.add')); ?>">
                <i class="ti-plus"></i> Add Patient
             </a>
        </div>
        <div class="col-md-12">
          <?php echo $__env->make('layouts.partials.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
              <div class="card-body">
                
                <div class="table-responsive">
                  <table class="table table-bordered table-hover" id="patientTable">
                    <thead>
                      <tr>
                        <th>
                          #
                        </th>
                        <th>
                          Names
                        </th>
                        <th>
                          Email
                        </th>
                        <th>
                          Phone Number
                        </th>
                        <th>
                            Location
                        </th>
                        
                        <th>
                          Actions
                        </th>
                      </tr>
                    </thead>
                   <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->iteration++); ?></td>
                                <td><?php echo e($patient->lastname); ?> <?php echo e($patient->firstname); ?></td>
                                <td><?php echo e($patient->email); ?></td>
                                <td><?php echo e($patient->phone_number); ?></td>
                                <td><?php echo e($patient->district); ?>-<?php echo e($patient->province); ?></td>
                                
                                <td>
                                    <div class="dropdown">
                                        <button class="btn btn-outline-primary py-2 dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false">
                                        Action
                                        </button>
                                        <div class="dropdown-menu">
                                        <a class="dropdown-item py-3" href="<?php echo e(route('patient.data',$patient->id)); ?>">ECG Data</a>
                                        <a class="dropdown-item py-3" href="<?php echo e(route('patient.edit',$patient->id)); ?>">Edit</a>
                                        <a class="dropdown-item py-3" href="#">Remove</a>
                                        </div>
                                  </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                   </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $('#patientTable').DataTable();
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/honore/Documents/Laravel_Projects/ECG_Web/resources/views/patient/index.blade.php ENDPATH**/ ?>